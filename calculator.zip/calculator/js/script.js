function display(val){
    document.getElementById('result').value += val

    return val
}





function solve(){

    let x = document.getElementById('result').value

    let y = eval(x);

    document.getElementById('result').value = y

    return y

}





function clearScreen(){

    document.getElementById('result').value = ''

}






function per(){
    let a = document.getElementById('result').value
    
     let b = (a*1.0)/100;
   document.getElementById('result').value = b;
       return b
}




    
    function clr() {
        var value = document.getElementById("result").value;
        document.getElementById("result").value = value.substr(0, value.length - 1);
    }
     
